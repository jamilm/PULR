// JavaScript Document
$(window).load(function(){
	$(".remove-text").text('');
});
